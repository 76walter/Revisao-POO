package com.example;

public class App 
{
    public static void main( String[] args )
    {
        Circulo meuCirculo = new Circulo(2);
        System.out.println("\nA area do circulo é: " + meuCirculo.CalcularAreaCirculo());
    }
}
