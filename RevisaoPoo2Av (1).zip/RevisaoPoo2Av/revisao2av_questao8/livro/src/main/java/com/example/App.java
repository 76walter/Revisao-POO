package com.example;

import java.util.Date;

public class App 
{
    public static void main( String[] args )
    {   
        Date data = new Date(1980);
        Livro novoLivro = new Livro("Homens e Caranguejos", "Josue de Castro", data);

    }
}
